#!/bin/bash

python main.py -n hermit -m training --run-folder training -d datasets/nlu_benchmark_hrc2/KFold_1 --gpu 0
