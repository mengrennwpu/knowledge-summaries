#!/bin/bash

python server.py -o json --run-folder resources/*_run_latest -w ../word_embeddings/glove.6B.300d.npz
